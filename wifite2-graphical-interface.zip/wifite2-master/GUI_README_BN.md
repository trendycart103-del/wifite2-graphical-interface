# Wifite2 GUI (Safe Read-only Edition)

## পেজ ও কাজ
- **Dashboard:** OS, Python এবং tool readiness summary.
- **Network Overview:** NetworkManager (`nmcli`) থেকে দৃশ্যমান Wi-Fi তালিকা।
- **Device & Tools:** wireless interface, network interface ও dependency status।
- **Audit Reports:** diagnostic তথ্য TXT ফাইলে export।
- **Settings:** GUI mode ও safety information।

## চালানোর নিয়ম (Kali/Ubuntu/Debian Linux)
```bash
sudo apt update
sudo apt install python3 python3-tk network-manager iw iproute2
python3 wifite_gui.py
```
GUI-টি সাধারণ user হিসেবেও চালানো যায়; diagnostic command-এর কিছু তথ্য সীমিত হতে পারে।

## গুরুত্বপূর্ণ
এই GUI read-only পর্যবেক্ষণ ও ডায়াগনস্টিকের জন্য। এটি Wifite2-এর আক্রমণ, deauthentication, brute-force, phishing, credential capture বা password-cracking ফাংশন চালু করে না। মূল CLI সোর্স অক্ষত রাখা হয়েছে, কিন্তু GUI থেকে চালানো হয় না। শুধু নিজের/অনুমোদিত নেটওয়ার্কে কাজ করুন।

## GitHub Actions
এটি Linux desktop Python/Tkinter GUI; Android APK নয়। GitHub-এ push করার পর Linux runner-এ সোর্স পরীক্ষা করা যায়। GUI দেখার জন্য Linux desktop-এ Tkinter runtime প্রয়োজন।
