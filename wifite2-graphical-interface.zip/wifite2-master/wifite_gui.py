#!/usr/bin/env python3
# Safe, read-only desktop interface for Wifite2 project diagnostics.
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import subprocess, shutil, platform, datetime, os

BG="#0b1220"; PANEL="#121d30"; CARD="#17243a"; ACCENT="#27d3b0"
FG="#e8f0fb"; MUTED="#9aabc2"; WARN="#f4bd50"

def run_readonly(args):
    try:
        p=subprocess.run(args, capture_output=True, text=True, timeout=8)
        return (p.stdout or p.stderr).strip() or "কোনো তথ্য পাওয়া যায়নি।"
    except Exception as e:
        return str(e)

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Wifite2 • Security Audit Console")
        self.geometry("1120x720"); self.minsize(900,600); self.configure(bg=BG)
        self.style=ttk.Style(self); self.style.theme_use("clam")
        self.style.configure("Treeview",background=CARD,foreground=FG,fieldbackground=CARD,rowheight=30)
        self.style.configure("Treeview.Heading",background=PANEL,foreground=ACCENT)
        self.build_shell(); self.show("Dashboard")
    def build_shell(self):
        side=tk.Frame(self,bg="#0e192a",width=225); side.pack(side="left",fill="y"); side.pack_propagate(False)
        tk.Label(side,text="◈  WIFITE2",bg="#0e192a",fg=ACCENT,font=("Arial",20,"bold")).pack(anchor="w",padx=20,pady=(25,4))
        tk.Label(side,text="SECURITY AUDIT CONSOLE",bg="#0e192a",fg=MUTED,font=("Arial",8,"bold")).pack(anchor="w",padx=22,pady=(0,25))
        for name in ["Dashboard","Network Overview","Device & Tools","Audit Reports","Settings"]:
            tk.Button(side,text="  "+name,anchor="w",relief="flat",bg="#0e192a",fg=FG,
                activebackground=CARD,activeforeground=ACCENT,font=("Arial",11),
                command=lambda n=name:self.show(n),padx=14,pady=12).pack(fill="x",padx=10,pady=2)
        tk.Label(side,text="READ-ONLY MODE\nশুধু পর্যবেক্ষণ ও ডায়াগনস্টিক\nকোনো আক্রমণ/পাসওয়ার্ড পরীক্ষা নয়",
                 bg="#0e192a",fg=WARN,font=("Arial",9),justify="left").pack(side="bottom",anchor="w",padx=20,pady=22)
        self.main=tk.Frame(self,bg=BG); self.main.pack(side="left",fill="both",expand=True)
    def clear(self):
        for w in self.main.winfo_children(): w.destroy()
    def header(self,title,sub):
        tk.Label(self.main,text=title,bg=BG,fg=FG,font=("Arial",24,"bold")).pack(anchor="w",padx=30,pady=(25,2))
        tk.Label(self.main,text=sub,bg=BG,fg=MUTED,font=("Arial",10)).pack(anchor="w",padx=31,pady=(0,22))
    def card(self,parent,title,value,desc):
        f=tk.Frame(parent,bg=CARD,padx=18,pady=16)
        tk.Label(f,text=title,bg=CARD,fg=MUTED,font=("Arial",10,"bold")).pack(anchor="w")
        tk.Label(f,text=value,bg=CARD,fg=ACCENT,font=("Arial",19,"bold")).pack(anchor="w",pady=6)
        tk.Label(f,text=desc,bg=CARD,fg=FG,font=("Arial",9),wraplength=220,justify="left").pack(anchor="w")
        return f
    def show(self,name):
        self.clear()
        if name=="Dashboard":
            self.header("Dashboard","সিস্টেমের অবস্থা ও নিরাপদ অডিট টুলের সারাংশ")
            row=tk.Frame(self.main,bg=BG); row.pack(fill="x",padx=30)
            tools=["python3","iw","nmcli","airmon-ng","airodump-ng","aircrack-ng"]
            present=sum(bool(shutil.which(x)) for x in tools)
            for title,val,desc in [("Operating System",platform.system(),platform.release()),("Python",platform.python_version(),"GUI runtime"),("Tools Ready",f"{present}/{len(tools)}","প্রয়োজনীয় কমান্ডের উপস্থিতি")]:
                self.card(row,title,val,desc).pack(side="left",fill="both",expand=True,padx=(0,12))
            self.section("দ্রুত কাজ")
            for title,desc,cmd in [("Network Overview","দৃশ্যমান নেটওয়ার্কের তালিকা দেখুন","Network Overview"),("Device & Tools","অ্যাডাপ্টার ও টুল পরীক্ষা করুন","Device & Tools"),("Audit Reports","ডায়াগনস্টিক রিপোর্ট তৈরি করুন","Audit Reports")]:
                self.action(title,desc,lambda n=cmd:self.show(n))
            self.note("সতর্কতা","শুধুমাত্র নিজের বা লিখিত অনুমতিপ্রাপ্ত নেটওয়ার্কে নিরাপত্তা মূল্যায়ন করুন। এই GUI কোনো deauthentication, brute-force, phishing বা password-cracking কাজ চালায় না।")
        elif name=="Network Overview":
            self.header("Network Overview","সিস্টেমের নেটওয়ার্ক ম্যানেজার থেকে দৃশ্যমান Wi-Fi তালিকা")
            bar=tk.Frame(self.main,bg=BG); bar.pack(fill="x",padx=30)
            tk.Button(bar,text="Refresh list",command=self.networks,bg=ACCENT,fg="#06221d",relief="flat",padx=18,pady=9).pack(side="left")
            self.net=tk.Text(self.main,bg=CARD,fg=FG,insertbackground=FG,relief="flat",font=("Courier",10),wrap="none")
            self.net.pack(fill="both",expand=True,padx=30,pady=18); self.networks()
        elif name=="Device & Tools":
            self.header("Device & Tools","অ্যাডাপ্টার ও নির্ভরশীল টুলের read-only পরীক্ষা")
            self.output=tk.Text(self.main,bg=CARD,fg=FG,relief="flat",font=("Courier",10),wrap="word")
            self.output.pack(fill="both",expand=True,padx=30,pady=10)
            text="SYSTEM\n"+platform.platform()+"\n\nWIRELESS INTERFACES\n"+run_readonly(["iw","dev"])+"\n\nNETWORK INTERFACES\n"+run_readonly(["ip","-brief","link"])+"\n\nDEPENDENCIES\n"
            for x in ["python3","iw","nmcli","airmon-ng","airodump-ng","aircrack-ng","tshark","wash","reaver","bully"]:
                text+=f"{x:18} {'FOUND: '+shutil.which(x) if shutil.which(x) else 'NOT FOUND'}\n"
            self.output.insert("1.0",text); self.output.configure(state="disabled")
        elif name=="Audit Reports":
            self.header("Audit Reports","ডায়াগনস্টিক তথ্যকে টেক্সট রিপোর্ট হিসেবে সংরক্ষণ")
            tk.Label(self.main,text="রিপোর্টে থাকবে OS, wireless interface ও dependency status।",bg=BG,fg=FG).pack(anchor="w",padx=30)
            tk.Button(self.main,text="Generate & Save Report",command=self.save_report,bg=ACCENT,fg="#06221d",relief="flat",padx=18,pady=12).pack(anchor="w",padx=30,pady=20)
        else:
            self.header("Settings","ইন্টারফেস সংক্রান্ত তথ্য")
            self.note("Interface mode","বর্তমান সংস্করণটি Linux desktop-এর জন্য Tkinter GUI।")
            self.note("Safety","এই সংস্করণে কেবল পর্যবেক্ষণ, dependency check এবং রিপোর্ট export রয়েছে।")
            self.note("Project compatibility","মূল Wifite2 command-line কোড অপরিবর্তিত রাখা হয়েছে; GUI সেটি চালু করে না।")
    def section(self,t): tk.Label(self.main,text=t,bg=BG,fg=FG,font=("Arial",15,"bold")).pack(anchor="w",padx=30,pady=(28,12))
    def action(self,t,d,fn):
        f=tk.Frame(self.main,bg=CARD,padx=16,pady=13); f.pack(fill="x",padx=30,pady=5)
        tk.Label(f,text=t,bg=CARD,fg=ACCENT,font=("Arial",12,"bold")).pack(anchor="w")
        tk.Label(f,text=d,bg=CARD,fg=FG,font=("Arial",9)).pack(anchor="w",pady=3)
        tk.Button(f,text="Open →",command=fn,bg=PANEL,fg=FG,relief="flat",padx=12).pack(anchor="e")
    def note(self,t,d):
        f=tk.Frame(self.main,bg=PANEL,padx=16,pady=12); f.pack(fill="x",padx=30,pady=7)
        tk.Label(f,text=t,bg=PANEL,fg=ACCENT,font=("Arial",11,"bold")).pack(anchor="w")
        tk.Label(f,text=d,bg=PANEL,fg=FG,wraplength=760,justify="left").pack(anchor="w",pady=4)
    def networks(self):
        if not hasattr(self,"net"): return
        self.net.delete("1.0","end")
        if shutil.which("nmcli"):
            result=run_readonly(["nmcli","-f","IN-USE,SSID,SECURITY,SIGNAL,CHAN","dev","wifi","list"])
        else: result="nmcli পাওয়া যায়নি। Linux-এ NetworkManager ইনস্টল/চালু থাকলে Wi-Fi তালিকা দেখা যাবে।"
        self.net.insert("1.0",result+"\n\nনোট: এটি NetworkManager-এর তালিকা; সব Wi-Fi অ্যাডাপ্টারে সমানভাবে কাজ নাও করতে পারে।")
    def save_report(self):
        tools=["python3","iw","nmcli","airmon-ng","airodump-ng","aircrack-ng","tshark","wash","reaver","bully"]
        report="WIFITE2 SAFE DIAGNOSTIC REPORT\n"+datetime.datetime.now().isoformat()+"\n"+platform.platform()+"\n\n"
        report+="WIRELESS\n"+run_readonly(["iw","dev"])+"\n\nINTERFACES\n"+run_readonly(["ip","-brief","link"])+"\n\nTOOLS\n"
        report+="\n".join(f"{x}: {shutil.which(x) or 'not found'}" for x in tools)
        path=filedialog.asksaveasfilename(defaultextension=".txt",filetypes=[("Text","*.txt")],initialfile="wifite2-diagnostic.txt")
        if path:
            with open(path,"w",encoding="utf-8") as f:f.write(report)
            messagebox.showinfo("Saved","রিপোর্ট সংরক্ষণ হয়েছে।")
if __name__=="__main__": App().mainloop()
