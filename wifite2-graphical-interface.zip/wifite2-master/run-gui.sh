#!/bin/sh
cd "$(dirname "$0")"
python3 wifite_gui.py
